'use client';

import s from './porto.module.css';
import Image from 'next/image';

const PROJECTS = [
  {
    num: '01',
    title: 'MotoLog',
    subtitle: 'Web App · Personal Product · Full Stack',
    tags: ['Next.js', 'Supabase', 'Custom SVG'],
    wip: false,
    summary: 'A personal motorcycle management dashboard tracking fuel efficiency, service intervals, and history with a custom SVG speedometer backed by Supabase.',
    origin: 'Self-initiated — solving my own daily problem as a motorcycle owner',
    role: 'Solo Developer · Full product (design, frontend, backend)',
    impacts: ['Designed and built a custom animated SVG speedometer drawn from scratch.', 'Implemented database backend with auth for cross-device use.', 'Calculates real fuel efficiency per refuel entry over time.'],
    learnings: 'Taught me end-to-end product ownership. I learned to scope feature sets without over-engineering and wire a modern frontend cleanly to a database.',
    link: 'https://rayhans.vercel.app/motolog',
    image: '/motolog-preview.png', // Ganti dengan path gambarmu di folder public/
  },
  {
    num: '02',
    title: 'NCOMM ESP-NOW Intercom',
    subtitle: 'Embedded System · IoT · Hardware Design',
    tags: ['ESP32', 'C++', 'Hardware Design'],
    wip: true,
    summary: 'A wireless helmet-to-helmet intercom built on ESP32 using ESP-NOW — a low-latency, connectionless Wi-Fi protocol for real-time audio without pairing.',
    origin: 'Self-initiated — for amateur radio field operations and touring',
    role: 'Solo Builder · Hardware design, firmware, enclosure',
    impacts: ['Achieved low-latency two-way voice bypassing Bluetooth pairing.', 'Solved interference from helmet vibration via software filtering.', 'Built a solution not commercially available at this price point in Indonesia.'],
    learnings: 'Real-time audio over wireless is unforgiving. I learned to profile firmware bottlenecks, handle audio streams in C++, and design for physical environments.',
    link: '',
    image: '/ncomm-preview.png',
  },
  {
    num: '03',
    title: 'APRS LoRa System',
    subtitle: 'Amateur Radio · Embedded · Networking',
    tags: ['LoRa', 'APRS', 'RF Networking'],
    wip: false,
    summary: 'A custom APRS implementation over LoRa radio combining long-range RF with amateur radio positioning for off-grid reporting.',
    origin: 'Self-initiated — extending amateur radio practice (YC5NCM)',
    role: 'Solo Builder · Hardware, firmware, protocol implementation',
    impacts: [
      'Implemented the APRS packet protocol from scratch on LoRa hardware.',
      'Connected to global APRS-IS network via iGate, making local stations globally visible.',
      'Contributed to local ORARI understanding of digital packet radio.',
    ],
    learnings: 'Forced me to understand fundamental networking protocols—packet framing, encoding, error tolerance—without relying on high-level libraries.',
    link: 'https://github.com/Rayhans21',
    image: '/lora-preview.png',
  },
  {
    num: '04',
    title: 'MUSDA IX Donation Log',
    subtitle: 'Web App · Civic Tech · Community',
    tags: ['Next.js', 'Google Sheets API', 'Real-time'],
    wip: false,
    summary: "A live donation tracking dashboard for ORARI's MUSDA IX conference. Updates to a Google Sheet reflect in real-time, providing transparency.",
    origin: 'Self-initiated — saw the need directly as an active ORARI member',
    role: 'Solo Developer · Full Stack',
    impacts: ['Replaced a manual spreadsheet process with a public live dashboard.', 'Allowed non-technical committee members to update data with zero training.', 'Archived as a permanent public transparency record of the event.'],
    learnings: 'The biggest lesson was designing for trust. Clear timestamps and source attribution were vital. I also learned simpler backends mean higher adoption.',
    link: 'https://rayhans.vercel.app/musda',
    image: 'public/musda-preview.png',
  },
  {
    num: '05',
    title: 'QO-100 Satellite Companion',
    subtitle: 'Arduino Tool · Satellite Communication',
    tags: ['Arduino', 'CAT Protocol', 'RF Logic'],
    wip: false,
    summary: 'An Arduino device reading transceiver frequencies via CAT protocol to auto-calculate the correct LNB offset for the QO-100 satellite uplink.',
    origin: 'Self-initiated — enabling satellite contacts without commercial accessories',
    role: 'Solo Builder · Firmware, hardware, RF logic',
    impacts: ['Automated LNB offset calculation, removing manual arithmetic.', 'Enabled contacts with stations across Europe, Africa, and Asia at low cost.', 'Sparked local community interest in satellite operations.'],
    learnings: 'Sat at the intersection of radio physics, serial protocols, and embedded programming. Showed how much can be achieved with a cheap board and deep curiosity.',
    link: 'https://github.com/Rayhans21',
    image: '/satellite-preview.png',
  },
];

export default function PortoPage() {
  const handlePrint = () => {
    const originalTitle = document.title;
    document.title = 'MuhammadRayhanSyah_Portfolio_Academy';
    window.print();
    setTimeout(() => {
      document.title = originalTitle;
    }, 100);
  };

  return (
    <div className={s.root}>
      <button className={s.fabPrint} onClick={handlePrint} title='Download PDF Portfolio'>
        <svg width='24' height='24' fill='none' stroke='currentColor' strokeWidth='2' viewBox='0 0 24 24'>
          <path
            strokeLinecap='round'
            strokeLinejoin='round'
            d='M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z'
          ></path>
        </svg>
      </button>

      {/* Cover Page */}
      <div className={s.page}>
        <div className={s.coverContent}>
          <div className={s.accentLine} />
          <p className={s.coverLabel}>PORTFOLIO 2025</p>
          <h1 className={s.coverName}>
            Muhammad
            <br />
            <span>Rayhan</span> Syah
          </h1>
          <p className={s.coverTagline}>Independent Developer · IoT Builder · Amateur Radio Operator (YC5NCM)</p>
          <p className={s.coverStatement}>
            I&apos;m a self-driven developer from Riau who builds at the intersection of web, hardware, and radio communication. Most of my projects start from a personal problem or a community need — I figure out what&apos;s missing, then
            I build it.
          </p>
        </div>
      </div>

      {/* 1 Page per Project Layout with Image Showcase */}
      {PROJECTS.map((p) => (
        <div key={p.num} className={s.page}>
          <div className={s.projectGrid}>
            {/* Left: Text Content */}
            <div className={s.projectInfo}>
              <div className={s.headerRow}>
                <h2 className={s.projectTitle}>
                  <span className={s.projectNum}>{p.num}.</span> {p.title}
                </h2>
                {p.wip && <span className={s.wipBadge}>WIP</span>}
              </div>
              <p className={s.projectSubtitle}>{p.subtitle}</p>

              <div className={s.tagRow}>
                {p.tags.map((t) => (
                  <span key={t} className={s.tag}>
                    {t}
                  </span>
                ))}
              </div>

              <div className={s.contentSection}>
                <h3>Summary</h3>
                <p>{p.summary}</p>
              </div>

              <div className={s.metaGrid}>
                <div>
                  <h3>Origin</h3>
                  <p>{p.origin}</p>
                </div>
                <div>
                  <h3>Role</h3>
                  <p>{p.role}</p>
                </div>
              </div>

              <div className={s.contentSection}>
                <h3>Impact & Contribution</h3>
                <ul>
                  {p.impacts.map((b, i) => (
                    <li key={i}>{b}</li>
                  ))}
                </ul>
              </div>

              <div className={s.contentSection}>
                <h3>What I Learned</h3>
                <p>{p.learnings}</p>
              </div>

              {p.link && <p className={s.projectLink}>🔗 {p.link}</p>}
            </div>

            {/* Right: Image Showcase */}
            <div className={s.projectImageWrapper}>
              <div className={s.imagePlaceholder}>{p.image ? <img src={p.image} alt={p.title} className={s.projectImg} /> : <p>No image available</p>}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
