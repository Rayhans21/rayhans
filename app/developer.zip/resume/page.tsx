'use client';

import s from './resume.module.css';

export default function ResumePage() {
  const handlePrintCV = () => {
    const originalTitle = document.title;
    document.title = 'MuhammadRayhanSyah_CV_Academy';
    window.print();
    setTimeout(() => {
      document.title = originalTitle;
    }, 100);
  };

  return (
    <div className={s.root}>
      <button className={s.fabPrint} onClick={handlePrintCV} title='Download PDF CV'>
        <svg width='24' height='24' fill='none' stroke='currentColor' strokeWidth='2' viewBox='0 0 24 24'>
          <path
            strokeLinecap='round'
            strokeLinejoin='round'
            d='M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z'
          ></path>
        </svg>
      </button>

      <div className={s.page}>
        {/* HEADER */}
        <header className={s.header}>
          <div>
            <h1 className={s.name}>Muhammad Rayhan Syah</h1>
            <p className={s.profession}>Connected Systems Developer | rayhans.vercel.app</p>
          </div>
          <div className={s.contactInfo}>
            <p>rayhan2102@gmail.com</p>
            <p>085263854182</p>
            <p>linkedin.com/in/muhammadrayhans</p>
          </div>
        </header>

        {/* 1. OBJECTIVE */}
        <section className={s.section}>
          <h2 className={s.sectionTitle}>Objective</h2>
          <p className={s.textContent}>
            Information Systems graduate and Connected Systems Developer aiming to join Apple Developer Academy. I bring hands-on experience bridging software development with hardware and radio frequency integration, eager to build
            impactful, human-centered digital solutions within a multidisciplinary team.
          </p>
        </section>

        {/* 2. EXPERIENCE */}
        <section className={s.section}>
          <h2 className={s.sectionTitle}>Experience</h2>

          <div className={s.itemGroup}>
            <div className={s.itemHeader}>
              <h3 className={s.itemRole}>
                Technical Operations & System Architect <span className={s.itemCompany}>• NCM Riau HT Sales and Rentals</span>
              </h3>
              <span className={s.itemDate}>Oct 2023 – Present</span>
            </div>
            <ul className={s.bulletList}>
              <li>Architected the full database schema and system logic for high-frequency equipment rentals.</li>
              <li>Engineered automated calculations for rental durations and real-time stock availability, drastically reducing manual accounting errors.</li>
            </ul>
          </div>

          <div className={s.itemGroup}>
            <div className={s.itemHeader}>
              <h3 className={s.itemRole}>
                Mobile Apps Developer (Assistant) <span className={s.itemCompany}>• Indonesia Cerdas Team</span>
              </h3>
              <span className={s.itemDate}>Jan 2023 – Jan 2025</span>
            </div>
            <ul className={s.bulletList}>
              <li>Developed and maintained functional mobile applications for the Competency Assessment Center.</li>
              <li>Focused on user-friendly interface design to ensure smooth user onboarding.</li>
            </ul>
          </div>

          <div className={s.itemGroup}>
            <div className={s.itemHeader}>
              <h3 className={s.itemRole}>
                Information Technology Lead <span className={s.itemCompany}>• PT. Radio Indragiri Mandiri</span>
              </h3>
              <span className={s.itemDate}>Sep 2021 – Sep 2025</span>
            </div>
            <ul className={s.bulletList}>
              <li>Led the digital transformation strategy and technical operations for the broadcasting entity.</li>
              <li>Made key technological decisions to support business innovation and digital licensing.</li>
            </ul>
          </div>
        </section>

        {/* 3. EDUCATION */}
        <section className={s.section}>
          <h2 className={s.sectionTitle}>Education</h2>

          <div className={s.itemGroup}>
            <div className={s.itemHeader}>
              <h3 className={s.itemRole}>Bachelor of Information Systems</h3>
              <span className={s.itemDate}>Graduated</span>
            </div>
            <p className={s.textContent} style={{ marginTop: '2px' }}>
              Universitas Islam Negeri Sultan Syarif Kasim Riau • Pekanbaru, Indonesia
            </p>
            <p className={s.textContent}>Focused on IT system design, software architecture, and hardware integration methodologies.</p>
          </div>
        </section>

        {/* 4. VOLUNTEER EXPERIENCE OR LEADERSHIP */}
        <section className={s.section}>
          <h2 className={s.sectionTitle}>Volunteer Experience or Leadership</h2>

          <div className={s.itemGroup}>
            <div className={s.itemHeader}>
              <h3 className={s.itemRole}>
                Active Operator & Technical Contributor <span className={s.itemCompany}>• ORARI Riau (YC5NCM)</span>
              </h3>
            </div>
            <p className={s.textContent}>
              Initiated and developed open-source civic tech tools for the community, including a live transparent Donation Log and digital networking tools. Actively mentor members on digital packet radio (APRS) and satellite tracking
              systems.
            </p>
          </div>

          <div className={s.itemGroup}>
            <div className={s.itemHeader}>
              <h3 className={s.itemRole}>
                Kwartir Management <span className={s.itemCompany}>• Indragiri Hilir Scout Movement</span>
              </h3>
            </div>
            <p className={s.textContent}>
              Contributed to institutional management and capacity building. Applied technical solutions to organizational management and participated in National SAR Agency Water Rescue Training for emergency readiness.
            </p>
          </div>
        </section>

        {/* 5. SKILLS & CERTIFICATIONS */}
        <section className={s.section}>
          <h2 className={s.sectionTitle}>Skills</h2>
          <div className={s.skillsGrid}>
            <div>
              <p className={s.skillsCategory}>Web & App Development</p>
              <p className={s.textContent}>Next.js, React, TypeScript, Python, HTML/CSS, Supabase, SQL, Git.</p>
            </div>
            <div>
              <p className={s.skillsCategory}>Embedded & Hardware</p>
              <p className={s.textContent}>ESP32, Arduino, C++, I2C/SPI Serial Comm, Custom PCB prototyping.</p>
            </div>
            <div>
              <p className={s.skillsCategory}>Networking & RF</p>
              <p className={s.textContent}>LoRa, APRS Protocol, ESP-NOW, Satellite Comm, iGate Systems.</p>
            </div>
            <div>
              <p className={s.skillsCategory}>Certifications</p>
              <p className={s.textContent}>Mobile Apps Developer (Dicoding), VSGA Web Developer (Kominfo).</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
